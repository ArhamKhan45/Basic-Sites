import React, { Component } from "react";
import "./CountrySelect.css";
import { Country, State, City } from "country-state-city";
export class CountrySelect extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedcountry: "",
      selectedstate: "",
    };
  }
  Country_handler = (event) => {
    this.setState(
      {
        selectedcountry: event.target.value,
      },
      () => {
        // console.log(this.state.selectedcountry);
      }
    );
  };
  State_handler = (event) => {
    this.setState(
      {
        selectedstate: event.target.value,
      },
      () => {
        // console.log(this.state.selectedstate);
      }
    );
  };

  render() {
    const displayCountry = Country.getAllCountries().map(
      (countryItem, index) => {
        return (
          <React.Fragment key={index}>
            <option value={countryItem.isoCode}>{countryItem.name}</option>;
          </React.Fragment>
        );
      }
    );
    const displaystate = State.getAllStates().map((StateItem, index) => {
      if (this.state.selectedcountry === StateItem.countryCode) {
        return (
          <React.Fragment key={index}>
            <option value={StateItem.isoCode}>{StateItem.name}</option>;
          </React.Fragment>
        );
      }
    });
    const displaycity = City.getAllCities().map((cityItem, index) => {
      if (this.state.selectedstate === cityItem.stateCode) {
        return (
          <React.Fragment key={index}>
            <option value={cityItem.isoCode}>{cityItem.name}</option>;
          </React.Fragment>
        );
      }
    });

    return (
      <div className="container main-box">
        <form action="#">
          <div className="ms-5">
            <label>Country</label>
            <select
              name="country"
              id=""
              className="country-box"
              onChange={this.Country_handler}
            >
              <option value="">Select The Country</option>
              {displayCountry}
            </select>
          </div>

          <br />
          <div className="ms-5 ">
            <label>State</label>
            <select
              name="state"
              id=""
              className="state-box"
              onChange={this.State_handler}
            >
              <option value="">Select The State</option>
              {displaystate}
            </select>
          </div>
          <br />
          <div className="ms-5">
            <label>City</label>
            <select name="City" id="" className="city-box ">
              <option value="">Select The Cities</option>
              {displaycity}
            </select>
          </div>
          <br />

          <button type="submit">Submit</button>
        </form>
      </div>
    );
  }
}

export default CountrySelect;
