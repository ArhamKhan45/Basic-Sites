import React, { Component } from "react";
import RandomFunc from "./RandomFunc";
import JSON from "./Randomdb.json";
import "./style.css";

// parent
class RandomClass extends Component {
  constructor(props) {
    super(props);
    this.state = {
      fakedata: JSON,
    };
  }

  render() {
    return (
      <React.Fragment>
        <RandomFunc datasender={this.state.fakedata} />
      </React.Fragment>
    );
  }
}
export default RandomClass;
