import React, { Component } from "react";
import axios from "axios";

class PostDataApi extends Component {
  constructor(props) {
    super(props);
    this.state = {
      postholder: [],
    };
  }
  componentDidMount() {
    axios
      .get("https://jsonplaceholder.typicode.com/posts")
      .then((res) => {
        console.log(res);
        this.setState({
          postholder: res.data,
        });
      })
      .catch((error) => {
        console.log(error);
        this.setState({
          errorMsg: "Error getting post",
        });
      });
  }
  //   render() {
  //     const { postholder } = this.state; //destructure
  //     return (
  //       <div>
  //         {postholder.length
  //           ? postholder.map((item) => <div key={item.id}>{item.title}</div>)
  //           : null}
  //       </div>
  //     );
  //   }
  // }
  // export default PostDataApi;

  render() {
    return (
      <div>
        {this.state.postholder.map((item) => {
          return <div key={item.id}>{item.title}</div>;
        })}
      </div>
    );
  }
}
export default PostDataApi;
