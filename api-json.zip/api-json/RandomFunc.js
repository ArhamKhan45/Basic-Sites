import React, { useState } from "react";
// child

function RandomFunc(props) {
  const [Readtoggle, setReadToggle] = useState(0);
  const displayData = props.datasender.map((item) => {
    let unique_id = "box" + item.id;
    function descriptionDetailHandler() {
      let detail = document.getElementById(unique_id);
      let detailchild = detail.querySelector(".itemdescription");
      if (Readtoggle == 0) {
        detailchild.classList.add("overflow-auto");
        detailchild.classList.remove("overflow-hidden");
        detailchild = detail.querySelector("#" + (unique_id + "-4"));
        detailchild.innerHTML = "Read Less";
        setReadToggle(1);
      } else {
        detailchild.classList.add("overflow-hidden");
        detailchild.classList.remove("overflow-auto");
        detailchild = detail.querySelector("#" + (unique_id + "-4"));
        detailchild.innerHTML = "Read More";
        setReadToggle(0);
      }
    }
    return (
      <div className="box text-center" id={unique_id}>
        <img
          src={item.image}
          alt=""
          className="img-fluid mx-auto border text-center mb-1"
        />
        <p className="fw-bolder ">
          {item.id}. {item.title}
        </p>
        <p className="itemdescription">{item.description}</p>
        <div>
          <button
            className=" btn btn-outline-success float-end"
            id={unique_id + "-4"}
            onClick={() => descriptionDetailHandler()}
          >
            Read More
          </button>
        </div>
      </div>
    );
  });

  return (
    <React.Fragment>
      <div style={{ textAlign: "center" }}>{displayData}</div>
    </React.Fragment>
  );
}
export default RandomFunc;
