import React, { Component } from "react";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css"; 
import "slick-carousel/slick/slick-theme.css";
import "./ReactCarousel.css";
import {
  BsArrowLeftSquare as LeftArrow,
  BsArrowRightSquare as RightArrow,
  BsFillCartDashFill as Hero,
} from "react-icons/bs";


import g1 from "./images/g1.jpg";
import g2 from "./images/g2.jpg";
import g3 from "./images/g3.jpg";
import g4 from "./images/g4.jpg";
import g5 from "./images/g5.jpg";
import g6 from "./images/g9.jpg";
import g7 from "./images/g11.jpg";
import g8 from "./images/g12.jpg";
class ReactCarousel extends Component {
  render() {
    const SlickArrowLeft = ({ currentSlide, slideCount, ...props }) => (
      <LeftArrow
        {...props}
        className={
          "slick-prev slick-arrow" +
          (currentSlide === 0 ? " slick-disabled" : "")
          
        }
        aria-hidden="true"
        aria-disabled={currentSlide === 0 ? true : false}
        type="button"
      
      />
    );
    const SlickArrowRight = ({ currentSlide, slideCount, ...props }) => (
      <RightArrow
      {...props}
      className={
        "slick-next slick-arrow" +
        (currentSlide === slideCount - 1 ? " slick-disabled" : "")
      }
      aria-hidden="true"
      aria-disabled={currentSlide === slideCount - 1 ? true : false}
      type="button"
      />
        
      
    );
    var settings = {
      dots: true,
      infinite: true,
      speed: 500,
      slidesToShow: 3,
      slidesToScroll: 3,
      initialSlide: 0,
      arrows: true,
      prevArrow: <SlickArrowLeft />,
      nextArrow: <SlickArrowRight />,
     
      responsive: [
        {
          breakpoint: 1024,
          settings: {
            slidesToShow: 3,
            slidesToScroll: 3,
            infinite: true,
            dots: true
          }
        },
        {
          breakpoint:768,
          settings: {
            slidesToShow: 2,
            slidesToScroll: 2,
            initialSlide: 2
          }
        },
        {
          breakpoint: 556,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1
          }
        }
      ]
    };
    return (
      <div >
        <Slider {...settings} className="">
          <div className="border carousel-box me-2">
            <img src={g1} alt="" className="img-fluid"  />
          </div>
          <div className="border carousel-box ">
            <img src={g2} alt="" className="img-fluid"   />
          </div>
          <div className="border carousel-box">
            <img src={g3} alt=""className="img-fluid"   />
          </div>
          <div className="border carousel-box">
           <img src={g4} alt="" className="img-fluid"  />
          </div>
          <div className="border carousel-box">
            <img src={g5} alt=""className="img-fluid"   />
          </div>
          <div className="border carousel-box">
           <img src={g6} alt=""className="img-fluid"   />
          </div>
          <div className="border carousel-box">
            <img src={g7} alt="" className="img-fluid"  />
          </div>
          <div className="border carousel-box">
           <img src={g8} alt="" className="img-fluid"  />
          </div>
        </Slider>
      </div>
    );
  }
}



export default ReactCarousel;


