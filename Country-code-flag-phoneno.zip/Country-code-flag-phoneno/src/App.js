// import "./App.css";

import CountryFlag from "./Components/CountryFlag.jsx";

function App() {
  return (
    <div className="App">
      <CountryFlag />
    </div>
  );
}

export default App;
