import React, { Component } from "react";
import "../Style/CountryFlag.css";
import { Country } from "country-state-city";
import "/node_modules/flag-icons/css/flag-icons.min.css";

class CountryFlag extends Component {
  constructor(props) {
    super(props);
    this.state = {
      phonecode: "+91",
      flagIconShow: " fi fi-in fis",
      error: "",
    };
  }
  countryHandler = (event) => {
    Country.getAllCountries().map((item) => {
      if (event.target.value === item.name) {
        if (item.phonecode.charAt(0) === "+") {
          this.setState(
            {
              phonecode: item.phonecode,
              flagIconShow:
                "fi fi-" + item.isoCode.toLocaleLowerCase() + " fis ",
            },
            () => {}
          );
        } else {
          this.setState(
            {
              phonecode: "+" + item.phonecode,
              flagIconShow:
                "fi fi-" + item.isoCode.toLocaleLowerCase() + " fis ",
            },
            () => {}
          );
        }
      }
      return null;
    });
  };
  render() {
    const showcountries = Country.getAllCountries().map((item, index) => {
      const a =
        item.name === "India" ? (
          <option key={index} selected>
            {item.name}
          </option>
        ) : (
          <option key={index}>{item.name}</option>
        );
      return a;
    });

    return (
      <div>
        <form action="/hello" method="post">
          <select onChange={this.countryHandler}>
            <option>select country </option>
            {showcountries}
          </select>
          <div className="custom-phonecode">
            {this.state.phonecode}
            <span className={this.state.flagIconShow}></span>
          </div>

          <input
            type="tel"
            name="phoneno"
            id=""
            placeholder="888 888 8888"
            pattern="[0-9]{10}"
            title="your phone no should be like [0-9]{10} "
          />
          <input type="Submit" defaultValue="submit" />
        </form>
      </div>
    );
  }
}
export default CountryFlag;
