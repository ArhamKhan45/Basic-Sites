import axios from "axios";
import React, { Component } from "react";
import "./CountrySelect.css";
export class CountrySelect extends Component {
  constructor(props) {
    super(props);
    this.state = {
      dataholder: [],
      cityholder: "",
      citylist: [],
      errormsg: "",
    };
  }
  componentDidMount() {
    axios
      .get(
        "https://raw.githubusercontent.com/dr5hn/countries-states-cities-database/master/countries%2Bcities.json"
      )

      .then((res) => {
        console.log(res.data);
        this.setState({
          dataholder: res.data,
        });
      })
      .catch((error) => {
        this.setState({
          errormsg: "data not found",
        });
        console.log(this.state.errormsg);
      });
  }
  Country_handler = async (event) => {
    console.log(event.target.value);
    this.setState(
      {
        cityholder: event.target.value,
      },
      () => {
        this.state.dataholder.map((citylist) => {
          if (citylist.name === this.state.cityholder) {
            this.setState(
              {
                citylist: citylist.cities,
              },
              () => {}
            );
          }
          return null;
        });
      }
    );
  };
  render() {
    const countryShow = this.state.dataholder.map((item) => {
      return (
        <React.Fragment key={item.id}>
          <option value={item.name}>{item.name}</option>
        </React.Fragment>
      );
    });
    const cityShow = this.state.citylist.map((item) => {
      console.log(item.name);
      return (
        <React.Fragment key={item.id}>
          <option value={item.name}>{item.name}</option>
        </React.Fragment>
      );
    });
    return (
      <div className="container main-box">
        <form action="#">
          <div className="ms-5">
            <label htmlFor="country">Country</label>
            <select
              name="country"
              id=""
              className="country-box"
              onChange={this.Country_handler}
            >
              <option value="">Select The Country</option>
              {countryShow}
            </select>
          </div>
          <br />
          <div className="ms-5">
            <label htmlFor="state">City</label>
            <select name="City" id="" className="city-box ">
              <option value="">Select The Cities</option>
              {cityShow}
            </select>
          </div>
          <br />
          <div className="ms-5 ">
            <label htmlFor="state">State</label>
            <select name="state" id="" className="state-box">
              <option value="">{this.state.cityholder} </option>
            </select>
          </div>
          <br />
          <button type="submit">Submit</button>
        </form>
      </div>
    );
  }
}

export default CountrySelect;
